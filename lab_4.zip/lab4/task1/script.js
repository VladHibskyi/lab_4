function changeImage(element) {
    var largeImage = document.getElementById('largeImage');
    largeImage.src = element.src;
}
